### snet

- 标准库处理tcp请求